export const ItemTypes = {
  KNIGHT: 'knight',
}
